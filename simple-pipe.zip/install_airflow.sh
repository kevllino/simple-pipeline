#!/usr/bin/env bash

sudo apt update
sudo apt -y install python3-pip
sudo apt install python3-pip

export AIRFLOW_GPL_UNIDECODE=yes
export SLUGIFY_USES_TEXT_UNIDECODE=yes

pip3 install apache-airflow

export PYSPARK_PYTHON=python3