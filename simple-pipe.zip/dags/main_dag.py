from datetime import timedelta

from airflow import DAG
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator

DEFAULT_DAG_ARGS = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': '2019-01-12',
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(seconds=30),
    'project_id': 'local_dag',
    'schedule_interval': None  # setup to a daily cron task later
}

ZIP_PATH = "/artifacts/composer-tutorial.zip"

with DAG('main_dag', default_args=DEFAULT_DAG_ARGS) as dag:

    t_add = SparkSubmitOperator(
        task_id='label',
        application="spark_jobs/add_job.py",  # main?
        py_files=ZIP_PATH,
        application_args=["--run_date", "{{ execution_date }}"],
        # Obviously needs to match the name of cluster created in the prior Operator.
        cluster_name='ml-pipeline-cluster-{{ ds_nodash }}',

    )